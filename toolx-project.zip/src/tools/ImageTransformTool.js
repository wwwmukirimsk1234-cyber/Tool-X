import sharp from 'sharp';
import { Tool } from '../core/Tool.js';

export class ImageTransformTool extends Tool {
  constructor(options = {}) {
    super({ name: 'ImageTransformTool', ...options });
  }

  async run(file) {
    const supportedRasters = ['.jpg', '.jpeg', '.png', '.webp', '.avif', '.tiff', '.gif'];
    if (!supportedRasters.includes(file.ext)) {
      return file;
    }

    let pipeline = sharp(file.buffer);

    if (this.options.width || this.options.height) {
      pipeline = pipeline.resize({
        width: this.options.width ? parseInt(this.options.width, 10) : undefined,
        height: this.options.height ? parseInt(this.options.height, 10) : undefined,
        fit: this.options.fit || 'cover',
        withoutEnlargement: true
      });
    }

    let targetExt = file.ext;
    if (this.options.format) {
      targetExt = `.${this.options.format.toLowerCase()}`;
      const quality = this.options.quality ? parseInt(this.options.quality, 10) : 80;

      switch (targetExt) {
        case '.jpg':
        case '.jpeg':
          pipeline = pipeline.jpeg({ quality });
          break;
        case '.png':
          pipeline = pipeline.png({ quality });
          break;
        case '.webp':
          pipeline = pipeline.webp({ quality });
          break;
        case '.avif':
          pipeline = pipeline.avif({ quality });
          break;
        default:
          break;
      }
    } else {
      const quality = this.options.quality ? parseInt(this.options.quality, 10) : 85;
      if (file.ext === '.jpg' || file.ext === '.jpeg') pipeline = pipeline.jpeg({ quality });
      if (file.ext === '.png') pipeline = pipeline.png({ quality });
      if (file.ext === '.webp') pipeline = pipeline.webp({ quality });
    }

    const outputBuffer = await pipeline.toBuffer();
    const newName = file.name.replace(/\.[^/.]+$/, targetExt);

    return {
      ...file,
      name: newName,
      ext: targetExt,
      buffer: outputBuffer
    };
  }
}