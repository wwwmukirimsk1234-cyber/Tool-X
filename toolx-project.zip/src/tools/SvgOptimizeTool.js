import { optimize } from 'svgo';
import { Tool } from '../core/Tool.js';

export class SvgOptimizeTool extends Tool {
  constructor(options = {}) {
    super({ name: 'SvgOptimizeTool', ...options });
  }

  async run(file) {
    if (file.ext !== '.svg') {
      return file;
    }

    const svgString = file.buffer.toString('utf8');
    const result = optimize(svgString, {
      path: file.path,
      multipass: this.options.multipass ?? true,
      ...this.options.svgoOptions
    });

    return {
      ...file,
      buffer: Buffer.from(result.data, 'utf8')
    };
  }
}