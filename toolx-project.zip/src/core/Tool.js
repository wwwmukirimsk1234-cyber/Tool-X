export class Tool {
  constructor(options = {}) {
    this.name = options.name || this.constructor.name;
    this.options = options;
  }

  async run(file) {
    throw new Error(`Tool '${this.name}' must implement the run(file) method.`);
  }
}