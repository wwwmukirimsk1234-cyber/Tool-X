import fs from 'fs/promises';
import path from 'path';

export class Pipeline {
  constructor(name = 'DefaultPipeline') {
    this.name = name;
    this.tools = [];
  }

  use(tool) {
    this.tools.push(tool);
    return this;
  }

  async processFile(filePath, customOptions = {}) {
    const stats = await fs.stat(filePath);
    if (!stats.isFile()) return;

    let fileData = {
      path: filePath,
      name: path.basename(filePath),
      ext: path.extname(filePath).toLowerCase(),
      buffer: await fs.readFile(filePath)
    };

    for (const tool of this.tools) {
      const mergedOptions = { ...tool.options, ...customOptions };
      const activeTool = Object.assign(Object.create(Object.getPrototypeOf(tool)), tool, { options: mergedOptions });
      
      fileData = await activeTool.run(fileData);
    }

    return fileData;
  }

  async runBatch({ input, output, pattern } = {}) {
    let filesToProcess = [];
    const stats = await fs.stat(input);

    if (stats.isDirectory()) {
      const entries = await fs.readdir(input, { withFileTypes: true });
      for (const entry of entries) {
        if (entry.isFile()) {
          const fullPath = path.join(input, entry.name);
          if (!pattern || new RegExp(pattern).test(entry.name)) {
            filesToProcess.push(fullPath);
          }
        }
      }
    } else if (stats.isFile()) {
      filesToProcess.push(input);
    }

    if (output) {
      await fs.mkdir(output, { recursive: true });
    }

    const results = [];
    for (const filePath of filesToProcess) {
      try {
        const processed = await this.processFile(filePath);
        if (processed && output) {
          const outPath = path.join(output, processed.name);
          await fs.writeFile(outPath, processed.buffer);
          results.push({ input: filePath, output: outPath, status: 'success' });
        } else if (processed) {
          results.push({ input: filePath, status: 'success', buffer: processed.buffer });
        }
      } catch (err) {
        results.push({ input: filePath, status: 'error', message: err.message });
      }
    }

    return results;
  }
}